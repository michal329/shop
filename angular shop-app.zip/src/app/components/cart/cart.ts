import { Component, OnInit } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { Router } from '@angular/router';
import { CartService } from '../../services/Cart.service';
import { CartItem } from '../../models/cart-item.model';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, DecimalPipe],
  templateUrl: './cart.html',
  styleUrls: ['./cart.css']
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];
  totalPrice = 0;
  totalItems = 0;

  constructor(
    private cartService: CartService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;
      this.totalPrice = this.cartService.getTotalPrice();
      this.totalItems = this.cartService.getTotalItems();
    });
  }

  increase(item: CartItem): void {
    const max = item.product.quantity;
    const maxAvailable = (max == null || max === 0) ? Infinity : max;
    if (item.quantity < maxAvailable) {
      this.cartService.updateQuantity(item.product.productId, item.quantity + 1);
    }
  }

  decrease(productId: number, currentQty: number): void {
    this.cartService.updateQuantity(productId, currentQty - 1);
  }

  remove(productId: number): void {
    this.cartService.removeFromCart(productId);
  }

  clearCart(): void {
    this.cartService.clearCart();
  }

  checkout(): void {
    alert('Checkout coming soon!');
  }

  continueShopping(): void {
    this.router.navigate(['/products']);
  }

  viewDetails(productId: number): void {
    this.router.navigate(['/products', productId]);
  }

  isAtMax(item: CartItem): boolean {
    const max = item.product.quantity;
    const maxAvailable = (max == null || max === 0) ? Infinity : max;
    return item.quantity >= maxAvailable;
  }
}