import { Routes } from '@angular/router';
import { ProductListComponent }   from './components/product-list/product-list';
import { ProductDetailComponent } from './components/product-detail/product-detail';
import { CartComponent }          from './components/cart/cart';
import { HomeComponent } from './components/home/home';

export const routes: Routes = [
  // Root path shows the new Home component (exact match)
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'products', component: ProductListComponent },
  { path: 'products/:id', component: ProductDetailComponent },
  { path: 'cart', component: CartComponent },
  // Unknown routes -> home
  { path: '**', redirectTo: '', pathMatch: 'full' }
];