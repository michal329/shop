export interface OrderItem {
  orderId: number;
  productId: number;
  quantity?: number;
}

export interface Order {
  orderId?: number;
  orderDate: string;
  orderSum: number;
  userId: number;
  orderItems: OrderItem[];
}