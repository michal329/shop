import { Component, OnInit } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ProductService } from '../../services/Product.service';
import { CartService } from '../../services/Cart.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, DecimalPipe],
  templateUrl: './product-detail.html',
  styleUrls: ['./product-detail.css']
})
export class ProductDetailComponent implements OnInit {
  product: Product | null = null;
  quantity = 1;
  isLoading = false;
  errorMsg = '';
  added = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private cartService: CartService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id) {
      this.router.navigate(['/products']);
      return;
    }
    this.loadProduct(id);
  }

  loadProduct(id: number): void {
    this.isLoading = true;
    this.productService.getProductById(id).subscribe({
      next: (p) => {
        this.product = p;
        this.isLoading = false;
      },
      error: () => {
        this.errorMsg = 'Product not found. The detail endpoint may not be enabled yet on the API.';
        this.isLoading = false;
      }
    });
  }

  private get maxAvailable(): number | null {
    const pAny = this.product as any;
    return pAny?.quantity ?? pAny?.unitsInStock ?? pAny?.stock ?? null;
  }

  increaseQty(): void {
    const max = this.maxAvailable;
    if (max == null) {
      this.quantity++;
      return;
    }
    if (this.quantity < max) {
      this.quantity++;
    }
  }

  decreaseQty(): void {
    if (this.quantity > 1) this.quantity--;
  }

  addToCart(): void {
    if (!this.product) return;
    // Respect available stock/quantity fields if provided by the API.
    const pAny = this.product as any;
    const maxAvailable = pAny?.quantity ?? pAny?.unitsInStock ?? pAny?.stock ?? null;
    if (maxAvailable != null && this.quantity > maxAvailable) {
      this.quantity = maxAvailable;
    }
    this.cartService.addToCart(this.product, this.quantity);
    this.added = true;
    setTimeout(() => (this.added = false), 1500);
  }

  goBack(): void {
    this.router.navigate(['/products']);
  }
}