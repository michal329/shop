import { Component, OnInit, NgZone } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { ProductService } from '../../services/Product.service';
import { CartService } from '../../services/Cart.service';
import { Product, PageResponse } from '../../models/product.model';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule, DecimalPipe, FormsModule],
  templateUrl: './product-list.html',
  styleUrls: ['./product-list.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  pageInfo: PageResponse<Product> | null = null;
  selectedCategory: number | null = null;

  currentPage = 1;
  pageSize = 12;

  initialized = false;
  isLoading = false;
  errorMsg = '';

  addedProductId: number | null = null;

  searchTerm = '';
  minPrice: number | null = null;
  maxPrice: number | null = null;
  sortBy: string = 'default';
  filterPanelOpen = false;

  // Expose Math for template
  Math = Math;

  get filteredProducts(): Product[] {
    let result = [...this.products];

    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      result = result.filter(p =>
        p.productName.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term)
      );
    }

    if (this.minPrice != null) {
      result = result.filter(p => p.price >= this.minPrice!);
    }
    if (this.maxPrice != null) {
      result = result.filter(p => p.price <= this.maxPrice!);
    }

    switch (this.sortBy) {
      case 'price-asc': result.sort((a, b) => a.price - b.price); break;
      case 'price-desc': result.sort((a, b) => b.price - a.price); break;
      case 'name-asc': result.sort((a, b) => a.productName.localeCompare(b.productName)); break;
      case 'name-desc': result.sort((a, b) => b.productName.localeCompare(a.productName)); break;
    }

    return result;
  }

  get hasActiveFilters(): boolean {
    return !!(this.searchTerm.trim() || this.minPrice != null || this.maxPrice != null || this.sortBy !== 'default');
  }

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private router: Router,
    private route: ActivatedRoute,
    private ngZone: NgZone
  ) {}

  ngOnInit(): void {
    // react to category query param changes and reload
    this.route.queryParams.subscribe(params => {
      const cat = params['category'];
      this.selectedCategory = cat ? Number(cat) : null;
      this.currentPage = 1;
      this.loadProducts();
    });

    // Also listen for navigation events to handle cases where the component
    // is reused by the router (navigating back from product detail or cart)
    this.router.events.subscribe((ev: any) => {
      if (ev instanceof (Object as any).getPrototypeOf((this.router as any).events).constructor) {
        // fallback defensive check: skip if event is not NavigationEnd
      }
    });

    // More robust NavigationEnd check (explicit import used in template earlier).
    this.router.events.subscribe(event => {
      // Only react to navigation completions for the primary outlet
      if ((event as any).constructor.name === 'NavigationEnd') {
        const url = (event as any).urlAfterRedirects || (event as any).url || '';
        // If we landed on /products (or the root mapped to it), reload to ensure data shows
        if (url === '/products' || url.startsWith('/products')) {
          // Pull any query param from the URL and reload
          const tree = this.router.parseUrl(url);
          const cat = tree.queryParams['category'];
          this.selectedCategory = cat ? Number(cat) : null;
          this.currentPage = 1;
          this.loadProducts();
        }
      }
    });

    // initial load (will be covered by queryParams subscription but keep for safety)
    this.loadProducts();
  }

  loadProducts(): void {
    // Only show spinner on subsequent loads, not on initial page open
    if (this.initialized) {
      this.isLoading = true;
    }
    this.errorMsg = '';

    const categoryIds = this.selectedCategory != null ? [this.selectedCategory] : undefined;

    this.productService.getProducts(this.currentPage, this.pageSize, categoryIds).subscribe({
      next: (response) => {
        this.ngZone.run(() => {
          this.products = response.data;
          this.pageInfo = response;
          this.isLoading = false;
          this.initialized = true;
        });
      },
      error: (err) => {
        this.ngZone.run(() => {
          console.log('ERROR:', err);
          this.errorMsg = 'Failed to load products. Make sure the API is running on https://localhost:44386/.';
          this.isLoading = false;
          this.initialized = true;
        });
      }
    });
  }

  addToCart(product: Product, event: Event): void {
    event.stopPropagation();
    this.cartService.addToCart(product, 1);
    this.addedProductId = product.productId;
    setTimeout(() => (this.addedProductId = null), 1200);
  }

  viewDetails(productId: number): void {
    this.router.navigate(['/products', productId]);
  }

  nextPage(): void {
    if (this.pageInfo?.hasNextPage) {
      this.currentPage++;
      this.loadProducts();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  prevPage(): void {
    if (this.pageInfo?.hasPreviousPage) {
      this.currentPage--;
      this.loadProducts();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.minPrice = null;
    this.maxPrice = null;
    this.sortBy = 'default';
  }

  toggleFilterPanel(): void {
    this.filterPanelOpen = !this.filterPanelOpen;
  }
}