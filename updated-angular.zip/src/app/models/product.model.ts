// Matches ProductDTO from the API exactly (camelCase version of C# PascalCase)
export interface Product {
  productId: number;
  productName: string;
  price: number;
  categoryId: number;
  description: string;
}

// Matches PageResponseDTO<T> from the API
export interface PageResponse<T> {
  data: T[];
  totalItems: number;
  currentPage: number;
  pageSize: number;
  hasPreviousPage: boolean;
  hasNextPage: boolean;
}