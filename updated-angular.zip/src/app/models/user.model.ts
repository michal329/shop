export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  shippingAddress?: string;
  isAdmin: boolean;
}