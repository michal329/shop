import { CartItem } from './cart-item.model';

export interface Order {
  id: number;
  userId: number;
  items: CartItem[];
  totalPrice: number;
  status: 'pending' | 'shipped' | 'delivered' | 'cancelled';
  orderDate: Date;
  deliveryDate?: Date;
}