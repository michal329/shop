import { Injectable, Inject, PLATFORM_ID, signal, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;

  // Signals for template-friendly reactive state
  private currentUserSignal = signal<User | null>(null);
  public readonly isLoggedInSignal = computed(() => this.currentUserSignal() !== null);
  public readonly isAdminSignal = computed(() => this.currentUserSignal()?.isAdmin || false);

  private mockUsers: User[] = [
    { id: 1, email: 'admin@shop.com', firstName: 'Admin', lastName: 'User', phone: '123-456-7890', shippingAddress: '123 Admin St', isAdmin: true },
    { id: 2, email: 'user@shop.com', firstName: 'Regular', lastName: 'User', phone: '098-765-4321', shippingAddress: '456 User Ave', isAdmin: false }
  ];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    let user = null;

    // בדיקה האם הקוד רץ בדפדפן לפני גישה ל-localStorage
    if (isPlatformBrowser(this.platformId)) {
      const storedUser = localStorage.getItem('currentUser');
      if (storedUser) {
        try {
          user = JSON.parse(storedUser);
        } catch (e) {
          console.error("Could not parse user from localStorage", e);
        }
      }
    }

    this.currentUserSubject = new BehaviorSubject<User | null>(user);
    this.currentUser = this.currentUserSubject.asObservable();

    // initialize signal to match subject
    this.currentUserSignal.set(user);
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public get isLoggedIn(): boolean {
    return this.currentUserSignal() !== null;
  }

  public get isAdmin(): boolean {
    return this.currentUserSignal()?.isAdmin || false;
  }

  login(email: string, password: string): Observable<User> {
    return new Observable(observer => {
      setTimeout(() => {
        const user = this.mockUsers.find(u => u.email === email);
        
        if (user && password === 'password123') {
          if (isPlatformBrowser(this.platformId)) {
            const mockToken = 'mock-jwt-token-' + Date.now();
            localStorage.setItem('currentUser', JSON.stringify(user));
            localStorage.setItem('token', mockToken);
          }
          this.currentUserSubject.next(user);
          this.currentUserSignal.set(user);
          observer.next(user);
          observer.complete();
        } else {
          observer.error({ error: { message: 'Invalid email or password' } });
        }
      }, 800);
    });
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('currentUser');
      localStorage.removeItem('token');
    }
    this.currentUserSubject.next(null);
    this.currentUserSignal.set(null);
  }

  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('token');
    }
    return null;
  }

  isAuthenticated(): boolean {
    return this.getToken() !== null;
  }

  register(userData: any): Observable<any> {
    return new Observable(observer => {
      setTimeout(() => {
        const exists = this.mockUsers.find(u => u.email === userData.email);
        if (exists) {
          observer.error({ error: { message: 'Email already registered' } });
          return;
        }

        const newUser: User = {
          id: this.mockUsers.length + 1,
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          phone: userData.phone || '',
          shippingAddress: userData.shippingAddress || '',
          isAdmin: false
        };

        this.mockUsers.push(newUser);
        observer.next({ message: 'Registration successful', user: newUser });
        observer.complete();
      }, 800);
    });
  }
}